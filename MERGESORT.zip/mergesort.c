#include <stdio.h>
#include <stdlib.h>

void mergesort(int *v, int inicio, int fim);
void merge(int *v, int inicio, int meio, int fim);

int main(){
    //MergeSort ou ordenacao por Mistura
    //ETAPAS
    //- divide recursivamente o vetor em subvetores ate que cada subvetor possua apenas 1 elemento
    //- combina dois subconjuntos de  forma ordenada para se obter um conjutno maior e ordenado
    //- repetimos esse processo ate ter apenas 1 conjnto, que 'e o conjunto final e agora, ordenado

    //PERFORMANCE
    /*
    MELHOR CASO: N log N -> algoritmo rapido
    pior caso: N log N
    estavel: nao modifica a ordem de elementos iguais
    desvantagens: recursivo


    */

    //VARIAVEIS
    int i, vetor[10] = {120, 150, 110, 130, 100, 160, 140, 190, 170, 180};


    printf("--------MERGESORT---------\n\n");
    printf("Vetor antes dda ordenacao: \n");
    printf("vetor ordenado por MergeSort\n");
    for(i = 0; i < 10; i++){
        printf("%d|", vetor[i]);
    }
    printf("\n\n");

    mergesort(vetor, 0, 9);//chamando a funcao

    printf("vetor ordenado por MergeSort\n");
    for(i = 0; i < 10; i++){
        printf("%d|", vetor[i]);
    }

}

void mergesort(int *v, int inicio, int fim){
    int meio;
    if(inicio < fim){
        meio = (inicio + fim) / 2;
        mergesort(v, inicio, meio);
        mergesort(v, meio+1, fim);
        merge(v, inicio, meio, fim);
    }
}

void merge(int *v, int inicio, int meio, int fim){
    int *temp, p1, p2, tamanho,i ,j, k;
    int fim1 = 0, fim2 = 0;
    tamanho = fim - inicio + 1; //tamanho do novo vetor
    p1 = inicio;
    p2 = meio+1;
    temp = (int *) malloc(tamanho*sizeof(int));
    if(temp != NULL){
        for(i = 0; i<tamanho; i++){/*continua at'e preencher todos os indices do novo vetor*/
            if(fim1 == 0 && fim2 == 0){/*veifica se algum dos subvetores chegou ao final*/
                //------ordenando-------
                if(v[p1] < v[p2]){
                    temp[i] = v[p1];
                    p1++;
                }else{
                    temp[i] = v[p2];
                    p2++;
                }
                //-----verificando se o vetor acabou------
                if(p1> meio) {fim1 = 1;}
                if(p2> fim) {fim2 = 1;}

            }else{
                if(fim1 == 1){/*foi o p1 que acabou? Copia o resto do p1 no vetor*/
                    temp[i] = v[p2];
                    p2++;
                }else{        /*foi o p2 que acabou? copia o resto do p1 no vetor*/
                    temp[i] = v[p1];
                    p1++;
                }
            }
        }
        //----copiando temp para o vetor passado como parametro;
        for(j = 0, k= inicio; j<tamanho; j++, k++){
            v[k] = temp[j];
        }
    }
    free(temp);//liberar o vetor temporario



}
