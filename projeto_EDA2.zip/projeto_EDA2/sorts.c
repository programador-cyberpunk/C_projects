
    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
    #include <math.h>
    #include "sorts.h"


    ///// fui fazendo e testando um de cada vez
    ///usamos as variaveis como letras ou numeros pra nao escrever mto e ficar menos confuso
    void bubbleSort(int arr[], int n){

        for (int i = 0; i < n-1; i++)
            for (int j = 0; j < n-i-1; j++)
                if (arr[j] > arr[j+1]) {
                    int temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;
                }

    }

    void selectionSort(int arr[], int n){

        for (int i = 0; i < n-1; i++) {
            int min_idx = i;
            for (int j = i+1; j < n; j++)
                if (arr[j] < arr[min_idx])
                    min_idx = j;
            int temp = arr[min_idx];
            arr[min_idx] = arr[i];
            arr[i] = temp;
        }

    }

    void insertionSort(int arr[], int n){

        for (int i = 1; i < n; i++) {
            int key = arr[i];
            int j = i - 1;
            while (j >= 0 && arr[j] > key) {
                arr[j+1] = arr[j];
                j--;
            }
            arr[j+1] = key;
        }

    }

    void merge(int arr[], int l, int m, int r) {
    int n1 = m - l + 1, n2 = r - m;

    int *L = malloc(n1 * sizeof(int));
    int *R = malloc(n2 * sizeof(int));

    if (!L || !R) {
        printf("Erro ao alocar memoria no merge\n");
        exit(1);
    }

    for (int i = 0; i < n1; i++) L[i] = arr[l + i];
    for (int j = 0; j < n2; j++) R[j] = arr[m + 1 + j];

    int i = 0, j = 0, k = l;
    while (i < n1 && j < n2)
        arr[k++] = (L[i] <= R[j]) ? L[i++] : R[j++];

    while (i < n1) arr[k++] = L[i++];
    while (j < n2) arr[k++] = R[j++];

    free(L);
    free(R);
}

    void mergeSort(int arr[], int l, int r) {
        if (l < r) {
            int m = l + (r - l)/2;
            mergeSort(arr, l, m);
            mergeSort(arr, m+1, r);
            merge(arr, l, m, r);
        }
    }

    int partition(int arr[], int low, int high) {
    int random_pivot = low + rand() % (high - low);
    int temp = arr[random_pivot];
    arr[random_pivot] = arr[high];
    arr[high] = temp;

    int pivot = arr[high];
    int i = low - 1;

    for (int j = low; j < high; j++) {
        if (arr[j] < pivot) {
            i++;
            int aux = arr[i];
            arr[i] = arr[j];
            arr[j] = aux;
        }
    }
    int aux = arr[i + 1];
    arr[i + 1] = arr[high];
    arr[high] = aux;

    return i + 1;
}

void quickSort(int arr[], int low, int high) {
    while (low < high) {
        int pi = partition(arr, low, high);
        if (pi - low < high - pi) {
            quickSort(arr, low, pi - 1);
            low = pi + 1;
        } else {
            quickSort(arr, pi + 1, high);
            high = pi - 1;
        }
    }
}

    void heapify(int arr[], int n, int i) {

        int largest = i, l = 2*i + 1, r = 2*i + 2;
        if (l < n && arr[l] > arr[largest]) largest = l;
        if (r < n && arr[r] > arr[largest]) largest = r;
        if (largest != i) {
            int temp = arr[i]; arr[i] = arr[largest]; arr[largest] = temp;
            heapify(arr, n, largest);
        }

    }

    void heapSort(int arr[], int n){

        for (int i = n/2 - 1; i >= 0; i--) heapify(arr, n, i);
        for (int i = n-1; i > 0; i--) {
            int temp = arr[0]; arr[0] = arr[i]; arr[i] = temp;
            heapify(arr, i, 0);
        }

    }

    void countingSort(int inputArray[], int numElementos){

        int maiorNumero = 0;

        for (int i = 0; i < numElementos; i++)
            if (inputArray[i] > maiorNumero) maiorNumero = inputArray[i];
        int* auxArray = (int*)calloc(maiorNumero + 1, sizeof(int));
        for (int i = 0; i < numElementos; i++) auxArray[inputArray[i]]++;
        for (int i = 1; i <= maiorNumero; i++) auxArray[i] += auxArray[i - 1];
        int* arrayOrdenado = (int*)malloc(numElementos * sizeof(int));
        for (int i = numElementos - 1; i >= 0; i--) {
            arrayOrdenado[auxArray[inputArray[i]] - 1] = inputArray[i];
            auxArray[inputArray[i]]--;
        }

        for (int i = 0; i < numElementos; i++) inputArray[i] = arrayOrdenado[i];
        free(auxArray);
        free(arrayOrdenado);

    }

    int getMax(int arr[], int n){

        int max = arr[0];
        for (int i = 1; i < n; i++)
            if (arr[i] > max) max = arr[i];
        return max;

    }

    void countSortRadix(int arr[], int n, int exp) {
    int *output = malloc(n * sizeof(int));
    int count[10] = {0};

    if (!output) {
        printf("Erro ao alocar memoria em countSortRadix\n");
        exit(1);
    }

    for (int i = 0; i < n; i++)
        count[(arr[i] / exp) % 10]++;

    for (int i = 1; i < 10; i++)
        count[i] += count[i - 1];

    for (int i = n - 1; i >= 0; i--) {
        output[count[(arr[i] / exp) % 10] - 1] = arr[i];
        count[(arr[i] / exp) % 10]--;
    }

    for (int i = 0; i < n; i++)
        arr[i] = output[i];

    free(output);
}


    void radixSort(int arr[], int n){

        int m = getMax(arr, n);
        for (int exp = 1; m / exp > 0; exp *= 10)
            countSortRadix(arr, n, exp);

    }

    typedef struct {
        int *dados;       // Array din�mico
        int capacidade;   // Capacidade atual no bagulho
        int tamanho;      // N�mero de elementos no bagulho
    } Balde;

    void bucketSort(int *vetor, int tamanho){

        if (tamanho <= 0) return; // Validacao b�sica

        //Encontrar o valor m�ximo para definir os intervalos
        int max_val = vetor[0];
        for (int i = 1; i < tamanho; i++) {
            if (vetor[i] > max_val) max_val = vetor[i];
        }

        // N�mero de bagulhos e c�lculo do intervalo
        const int NUM_BUCKETS = 10;
        int intervalo = (max_val / NUM_BUCKETS) + 1; // pra nao fazer divisao por zero

        //Inicializar os bagulhos dinamicos
        Balde *baldes = malloc(NUM_BUCKETS * sizeof(Balde));
        for (int i = 0; i < NUM_BUCKETS; i++){

            baldes[i].dados = malloc(sizeof(int) * 2);
            baldes[i].capacidade = 2;
            baldes[i].tamanho = 0;
        }

        // Distribuir elementos nos bagulhos
        for (int i = 0; i < tamanho; i++){

            int indice = vetor[i] / intervalo;
            indice = (indice >= NUM_BUCKETS) ? NUM_BUCKETS - 1 : indice; //pra limitar

            // Redimensiona se der merda
            if (baldes[indice].tamanho == baldes[indice].capacidade){

                baldes[indice].capacidade *= 2;
                baldes[indice].dados = realloc(baldes[indice].dados, baldes[indice].capacidade * sizeof(int));
            }

            baldes[indice].dados[baldes[indice].tamanho++] = vetor[i];
        }

        // Passo 4: Ordenar cada balde e reconstruir o vetor
        int idx = 0;
        for (int i = 0; i < NUM_BUCKETS; i++) {
            insertionSort(baldes[i].dados, baldes[i].tamanho);
            for (int j = 0; j < baldes[i].tamanho; j++) {
                vetor[idx++] = baldes[i].dados[j];
            }
            free(baldes[i].dados); // Libera mem�ria do balde
        }

        free(baldes); // Libera array de baldes
    }

    void shellSort(int arr[], int n){

        for (int gap = n/2; gap > 0; gap /= 2)
            for (int i = gap; i < n; i++) {
                int temp = arr[i], j;
                for (j = i; j >= gap && arr[j - gap] > temp; j -= gap)
                    arr[j] = arr[j - gap];
                arr[j] = temp;
            }
    }

    #define RUN 32

    int min(int a, int b) {
        return a < b ? a : b;
    }

    void insertSort(int array[], int esq, int dir){

        for (int index = esq + 1; index <= dir; index++) {
            int chave = array[index];
            int x = index - 1;
            while (x >= esq && array[x] > chave) {
                array[x + 1] = array[x];
                x--;
            }
            array[x + 1] = chave;
        }

    }

    void mergeTim(int array[], int x, int y, int z) {
    int el1 = y - x + 1, el2 = z - y;

    int *esq = malloc(el1 * sizeof(int));
    int *dir = malloc(el2 * sizeof(int));
    if (!esq || !dir) {
        printf("Erro ao alocar memoria no mergeTim.\n");
        exit(1);
    }

    for (int i = 0; i < el1; i++) esq[i] = array[x + i];
    for (int i2 = 0; i2 < el2; i2++) dir[i2] = array[y + 1 + i2];

    int i = 0, i2 = 0, i3 = x;
    while (i < el1 && i2 < el2)
        array[i3++] = (esq[i] <= dir[i2]) ? esq[i++] : dir[i2++];

    while (i < el1) array[i3++] = esq[i++];
    while (i2 < el2) array[i3++] = dir[i2++];

    free(esq);
    free(dir);
}

    void timSort(int array[], int n) {
        for (int i = 0; i < n; i += RUN)
            insertSort(array, i, min((i + RUN - 1), (n - 1)));
        for (int arm = RUN; arm < n; arm = 2 * arm)
            for (int esq = 0; esq < n; esq += 2 * arm) {
                int meio = esq + arm - 1;
                int dir = min((esq + 2 * arm - 1), (n - 1));
                if (meio < dir) mergeTim(array, esq, meio, dir);
            }
    }

