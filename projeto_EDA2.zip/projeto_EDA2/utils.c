#include "utils.h"

double calcularTempo(struct timeval inicio, struct timeval fim) {
    return (fim.tv_sec - inicio.tv_sec) * 1000000.0 + (fim.tv_usec - inicio.tv_usec);
}

const char* nomeAlgoritmo(int opcao) {
    const char* nomes[] = {
        "BubbleSort", "InsertionSort", "SelectionSort", "ShellSort", "MergeSort",
        "QuickSort", "HeapSort", "BucketSort", "RadixSort", "CountingSort", "TimSort"
    };
    if (opcao >= 1 && opcao <= 11) return nomes[opcao - 1];
    return "Desconhecido";
}

void usarVetor(int *vetor, int n) {
    volatile int dummy = 0;
    for (int i = 0; i < n; i++)
        dummy += vetor[i];
}
