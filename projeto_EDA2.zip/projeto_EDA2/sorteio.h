#ifndef SORTEIOS_H
#define SORTEIOS_H

int* gerarVetorAleatorio(int n);
int* gerarVetorOrdenado(int n);
int* gerarVetorDecrescente(int n);
int estaOrdenado(int *vetor, int n);

#endif
