#ifndef SORTS_H
#define SORTS_H

void bubbleSort(int arr[], int n);
void selectionSort(int arr[], int n);
void insertionSort(int arr[], int n);
void mergeSort(int arr[], int l, int r);
void quickSort(int arr[], int low, int high);
void heapSort(int arr[], int n);
void countingSort(int inputArray[], int numElementos);
void radixSort(int arr[], int n);
void bucketSort(int *vetor, int tamanho);
void shellSort(int arr[], int n);
void timSort(int arr[], int n);

#endif
