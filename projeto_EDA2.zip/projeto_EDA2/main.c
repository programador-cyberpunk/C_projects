#include <stdio.h>
#include <stdlib.h>
#include "teste.h"

int main() {
    int opcaoAlgoritmo, opcaoTamanho;
    int tamanhos[] = {10000, 50000, 100000, 200000, 500000, 1000000};
    FILE *arquivo = fopen("resultados.csv", "w");
    if (!arquivo) {
        printf("Erro ao abrir arquivo.\n");
        return 1;
    }
    fprintf(arquivo, "Algoritmo,Tamanho,Cenario,Tempo\n");

    while (1) {
        printf("\n==== MENU PRINCIPAL ====\n");
        printf("1. BubbleSort\n2. InsertionSort\n3. SelectionSort\n4. ShellSort\n5. MergeSort\n");
        printf("6. QuickSort\n7. HeapSort\n8. BucketSort\n9. RadixSort\n10. CountingSort\n11. TimSort\n");
        printf("0. Sair\nEscolha: ");
        scanf("%d", &opcaoAlgoritmo);
        if (opcaoAlgoritmo == 0) break;

        printf("Tamanhos dispon�veis:\n");
        for (int i = 0; i < 6; i++)
            printf("%d. %d elementos\n", i + 1, tamanhos[i]);
        printf("Escolha: ");
        scanf("%d", &opcaoTamanho);
        if (opcaoTamanho < 1 || opcaoTamanho > 6) continue;

        executarTestes(opcaoAlgoritmo, tamanhos[opcaoTamanho - 1], arquivo);
    }

    fclose(arquivo);
    return 0;
}
