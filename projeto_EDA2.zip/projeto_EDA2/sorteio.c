#include <stdlib.h>
#include <stdio.h>
#include "sorteio.h"

int* gerarVetorAleatorio(int n) {
    int *vet = malloc(n * sizeof(int));
    if (!vet) {
        printf("Erro ao alocar memoria.\n");
        exit(1);
    }
    for (int i = 0; i < n; i++)
        vet[i] = rand() % 1000000;
    return vet;
}

int* gerarVetorOrdenado(int n) {
    int *vet = malloc(n * sizeof(int));
    if (!vet) {
        printf("Erro ao alocar memoria.\n");
        exit(1);
    }
    for (int i = 0; i < n; i++)
        vet[i] = i;
    return vet;
}

int* gerarVetorDecrescente(int n) {
    int *vet = malloc(n * sizeof(int));
    if (!vet) {
        printf("Erro ao alocar memoria.\n");
        exit(1);
    }
    for (int i = 0; i < n; i++)
        vet[i] = n - i;
    return vet;
}

int estaOrdenado(int *vetor, int n) {
    for (int i = 0; i < n - 1; i++)
        if (vetor[i] > vetor[i + 1])
            return 0;
    return 1;
}
