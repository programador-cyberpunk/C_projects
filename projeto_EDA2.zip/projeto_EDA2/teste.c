#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include "sorts.h"
#include "sorteio.h"
#include "utils.h"
#include "teste.h"

#define NUM_REPETICOES 10

void executarTestes(int opcaoAlgoritmo, int tamanho, FILE *arquivo) {
    double tempoTotal = 0.0;
    struct timeval inicio, fim;
    const char *nome = nomeAlgoritmo(opcaoAlgoritmo);
    int *vetor = NULL;

    for (int i = 0; i < NUM_REPETICOES; i++) {
        vetor = gerarVetorAleatorio(tamanho);
        gettimeofday(&inicio, NULL);
        switch(opcaoAlgoritmo) {
            case 1: bubbleSort(vetor, tamanho); break;
            case 2: insertionSort(vetor, tamanho); break;
            case 3: selectionSort(vetor, tamanho); break;
            case 4: shellSort(vetor, tamanho); break;
            case 5: mergeSort(vetor, 0, tamanho-1); break;
            case 6: quickSort(vetor, 0, tamanho-1); break;
            case 7: heapSort(vetor, tamanho); break;
            case 8: bucketSort(vetor, tamanho); break;
            case 9: radixSort(vetor, tamanho); break;
            case 10: countingSort(vetor, tamanho); break;
            case 11: timSort(vetor, tamanho); break;
        }
        gettimeofday(&fim, NULL);
        double tempo = calcularTempo(inicio, fim);
        tempoTotal += tempo;
        if (!estaOrdenado(vetor, tamanho))
            printf("Vetor NAO ordenado corretamente na execucao %d\n", i + 1);
        usarVetor(vetor, tamanho);
        fprintf(arquivo, "%s,%d,Aleatorio,%.2lf\n", nome, tamanho, tempo);
        free(vetor);
    }

    printf("Media Aleatorio (%s, %d): %.2lf us\n", nome, tamanho, tempoTotal / NUM_REPETICOES);

    double tempoOrdenado = 0.0;
    for (int i = 0; i < NUM_REPETICOES; i++) {
        vetor = gerarVetorOrdenado(tamanho);
        gettimeofday(&inicio, NULL);
        switch(opcaoAlgoritmo) {
            case 1: bubbleSort(vetor, tamanho); break;
            case 2: insertionSort(vetor, tamanho); break;
            case 3: selectionSort(vetor, tamanho); break;
            case 4: shellSort(vetor, tamanho); break;
            case 5: mergeSort(vetor, 0, tamanho-1); break;
            case 6: quickSort(vetor, 0, tamanho-1); break;
            case 7: heapSort(vetor, tamanho); break;
            case 8: bucketSort(vetor, tamanho); break;
            case 9: radixSort(vetor, tamanho); break;
            case 10: countingSort(vetor, tamanho); break;
            case 11: timSort(vetor, tamanho); break;
        }
        gettimeofday(&fim, NULL);
        double tempo = calcularTempo(inicio, fim);
        tempoOrdenado += tempo;
        if (!estaOrdenado(vetor, tamanho))
            printf("Ordenado: falhou (%d)\n", i + 1);
        usarVetor(vetor, tamanho);
        free(vetor);
    }
    fprintf(arquivo, "%s,%d,Ordenado,%.2lf\n", nome, tamanho, tempoOrdenado / NUM_REPETICOES);
    printf("Media Ordenado: %.2lf us\n", tempoOrdenado / NUM_REPETICOES);

    double tempoDecrescente = 0.0;
    for (int i = 0; i < NUM_REPETICOES; i++) {
        vetor = gerarVetorDecrescente(tamanho);
        gettimeofday(&inicio, NULL);
        switch(opcaoAlgoritmo) {
            case 1: bubbleSort(vetor, tamanho); break;
            case 2: insertionSort(vetor, tamanho); break;
            case 3: selectionSort(vetor, tamanho); break;
            case 4: shellSort(vetor, tamanho); break;
            case 5: mergeSort(vetor, 0, tamanho-1); break;
            case 6: quickSort(vetor, 0, tamanho-1); break;
            case 7: heapSort(vetor, tamanho); break;
            case 8: bucketSort(vetor, tamanho); break;
            case 9: radixSort(vetor, tamanho); break;
            case 10: countingSort(vetor, tamanho); break;
            case 11: timSort(vetor, tamanho); break;
        }
        gettimeofday(&fim, NULL);
        double tempo = calcularTempo(inicio, fim);
        tempoDecrescente += tempo;
        if (!estaOrdenado(vetor, tamanho))
            printf("Decrescente: falhou (%d)\n", i + 1);
        usarVetor(vetor, tamanho);
        free(vetor);
    }
    fprintf(arquivo, "%s,%d,Decrescente,%.2lf\n", nome, tamanho, tempoDecrescente / NUM_REPETICOES);
    printf("Media Decrescente: %.2lf us\n", tempoDecrescente / NUM_REPETICOES);
}
