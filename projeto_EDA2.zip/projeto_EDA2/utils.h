#ifndef UTILS_H
#define UTILS_H

#include <sys/time.h>

double calcularTempo(struct timeval inicio, struct timeval fim);
const char* nomeAlgoritmo(int opcao);
void usarVetor(int *vetor, int n);

#endif
