#ifndef TESTES_H
#define TESTES_H

void executarTestes(int opcaoAlgoritmo, int tamanho, FILE *arquivo);

#endif
