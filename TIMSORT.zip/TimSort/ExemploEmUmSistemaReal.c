/*
Semin�rio TimSort:
    TimSort � um algoritmo de ordena��o h�brido, que combina dois outros m�todos de ordena��o (MergeSort e InsertionSort) para organizar arrays
    de forma mais eficiente. Inicialmente criado para a linguagem Python, TimSort funciona dividindo um array em pequenas partes chamadas 'runs',
    ordenando cada uma delas com o InsertionSort. Ap�s essa etapa, as partes s�o mescladas utilizando o MergeSort, garantindo um melhor desempenho
    para listas parcialmente ordenadas. O resultado final � um array ordenado de forma decrescente.

    O seu processo ocorre em duas grandes fases:
        Ordena��o das RUNS - Onde o array � divido entre pequenas listas menores, ou subArrays com tamanhos de cada RUN e ordenado individualmente usando InsertionSort.
        Mesclagem de RUNS - Os subArrays s�o combinados e ordenados progressivamente, utilizando o m�todo MergeSort, at� que o array original se complete.

    Para seu funcionamento ideal, � necess�rio determinar o tamanho adequado das runs, o que depende da necessidade do problema.
    Esse m�todo � ideal para arrays parcialmente ordenados, sendo est�vel e adaptativo. Ele � eficiente e escal�vel, tornando-se uma solu��o
    vantajosa em rela��o a outros algoritmos de ordena��o, como o InsertionSort.
*/

// Import de bibliotecas necess�rias para execu��o efetiva do c�digo:
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define RUN 32 // Defini��o do tamanho m�nimo do bloco para o InsertionSort.

typedef struct {
    char nome[50];
    int score; // Score banc�rio do cliente
} Cliente;

int min(int a, int b) { // Fun��o para definir o m�nimo de dois n�meros
    return (a < b) ? a : b;
}

/*
A fun��o insertSort() implementa o algoritmo que divide o array em pequenos subarrays, ou seja, listas menores que
ser�o ordenadas em ordem decrescente (do maior para o menor).
*/
void insertSort(Cliente clientes[], int esq, int dir) {
    for (int index = esq + 1; index <= dir; index++) {
        Cliente chave = clientes[index];
        int x = index - 1;
        while (x >= esq && clientes[x].score < chave.score) { // Compara��o ajustada para ordem decrescente
            clientes[x + 1] = clientes[x];
            x--;
        }
        clientes[x + 1] = chave;
    }
}

/*
A fun��o mergeSort() implementa o algoritmo que mescla dois subarrays ordenados dentro de um array principal.
Ela recebe um array e tr�s �ndices: x (in�cio do primeiro subarray), y (fim do primeiro subarray e in�cio do segundo) e z (fim do segundo subarray).
Os elementos s�o copiados para dois arrays auxiliares (esq e dir), depois comparados e mesclados de volta ao array principal em ordem decrescente.
*/
void mergeSort(Cliente clientes[], int x, int y, int z) {
    int el1 = y - x + 1, el2 = z - y;
    Cliente esq[el1], dir[el2];
    for (int i = 0; i < el1; i++) {
        esq[i] = clientes[x + i];
    }
    for (int i2 = 0; i2 < el2; i2++) {
        dir[i2] = clientes[y + 1 + i2];
    }
    int i = 0, i2 = 0, i3 = x;
    while (i < el1 && i2 < el2) {
        if (esq[i].score >= dir[i2].score) { // Compara��o ajustada para ordem decrescente
            clientes[i3] = esq[i];
            i++;
        } else {
            clientes[i3] = dir[i2];
            i2++;
        }
        i3++;
    }
    while (i < el1) {
        clientes[i3] = esq[i];
        i++;
        i3++;
    }
    while (i2 < el2) {
        clientes[i3] = dir[i2];
        i2++;
        i3++;
    }
}

void timSort(Cliente clientes[], int n) { // Fun��o que executa o m�todo TimSort:
    for (int i = 0; i < n; i += RUN) {
        insertSort(clientes, i, min((i + RUN - 1), (n - 1))); // Ordena cada subarray em ordem decrescente
    }
    for (int arm = RUN; arm < n; arm = 2 * arm) { // Mescla os subarrays usando MergeSort
        for (int esq = 0; esq < n; esq += 2 * arm) {
            int meio = esq + arm - 1;
            int dir = min((esq + 2 * arm - 1), (n - 1));
            if (meio < dir) {
                mergeSort(clientes, esq, meio, dir);
            }
        }
    }
}

int main() { // Fun��o main() para executar todo o funcionamento do algoritmo TimSort.
    Cliente clientes[] = {
        {"Carlos", 750},
        {"Ana", 820},
        {"Roberto", 650},
        {"Mariana", 900},
        {"Paulo", 720},
        {"Fernanda", 880},
        {"Jos�", 770},
        {"Camila", 910},
        {"Ricardo", 680},
        {"Juliana", 890}
    };
    int n = 10;

    printf("Clientes antes da ordena��o:\n");
    for (int i = 0; i < n; i++) {
        printf("Nome: %s, Score: %d\n", clientes[i].nome, clientes[i].score);
    }
    printf("\n");

    timSort(clientes, n);

    printf("Clientes ap�s a ordena��o em ordem decrescente por score:\n");
    for (int i = 0; i < n; i++) {
        printf("Nome: %s, Score: %d\n", clientes[i].nome, clientes[i].score);
    }
    printf("\n");
    return 0;
}
