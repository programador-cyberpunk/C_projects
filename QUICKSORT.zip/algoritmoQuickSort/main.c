#include <stdio.h>
#include <stdlib.h>
#include "quick.h"

int main(){

    int arr[] = {10, 7, 8, 9, 1, 5};
    int n = sizeof(arr) / sizeof(arr[0]); // Calcula tamanho do Array

    printf("Array antes da ordenação: ");
    printArray(arr, n);

    quickSort(arr, 0, n - 1);

    printf("Array ordenado: ");
    printArray(arr, n);

    return 0;

}
