#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include "biblioteca_com_sorts.h"

int main()
{
    setlocale(0, "Portuguese");
    int i; //para fins de for

    //vetor desordenado:
    int v[10] = {30, 20, 40, 10, 60, 50, 80, 90, 100, 70};
    printf("M�todo InsertionSort:\n\n");
    //Agora, vamos para a biblioteca.c onde est� montado o InsertionSort
    printf("Valores do array desordenado v:\t");
    for(i = 0; i < 10; i++){
        i < 9 ? printf(" %d,", v[i]): printf(" %d\n", v[i]);
    }
    //Voltando, vamos organizar nosso vetor, para isso, vamos chamar InsertionSort();
    InsertionSort(v, 10);
    printf("Valores do array ja ordenado v:\t", i, v[i]);
    for(i = 0; i < 10; i++){
        i < 9 ? printf(" %d,", v[i]) : printf(" %d", v[i]);
    }

    printf("\n\n\n");
    //vetor desordenado:
    int w[10] = {30, 20, 40, 10, 60, 50, 80, 90, 100, 70};
    printf("M�todo ShellSort:\n\n");
    //Agora, vamos para a biblioteca.c onde est� montado o Shellsort
    printf("Valores do array desordenado w:\t");
    for(i = 0; i < 10; i++){
            i < 9 ? printf(" %d,", w[i]): printf(" %d\n", w[i]);
    }
    //Voltando, vamos organizar nosso vetor, para isso, vamos chamar InsertionSort();
    ShellSort(w, 10);

    printf("Valores do array ja ordenado w:\t", i, w[i]);
    for(i = 0; i < 10; i++){
            i < 9 ? printf(" %d,", w[i]) : printf(" %d", w[i]);
    }
    printf("\n\n\n");
    system("pause");
    return 0;
}
