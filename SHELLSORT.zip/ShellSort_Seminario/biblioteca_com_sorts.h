void InsertionSort(int arr[], int tam);
//ordena��o de vetor de inteiros por Insertion Sort

void ShellSort(int arr[], int tam);
//ordena��o de vetor de inteiros por Shell Sort
