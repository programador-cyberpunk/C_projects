// Arquivo main.c - Ordena��o Radix Sort com sele��o de base
// Feito por Lucas Silva de Oliveira
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include "radixSortE.h"

int main()
{
    setlocale(LC_ALL, "");
    printf("Ordena��o Radix Sort\n");

    unsigned int *arr; // Ponteiro para a lista
    unsigned int radix, n = 0, digit = 2; // radix = base da lista | n = n�mero de elementos

    do{
        printf("Qual � a base dos elementos da lista?\n|[1] Bin�rio | [2] Octal | [3] Decimal | [4] Hexadecimal |\n");
        scanf("%u", &radix);
        if(radix < 1 || radix > 4)
            printf("Entrada inv�lida!");
        else break;
    }while(1);
    switch(radix){
        case 1:
            radix = 2;
            break;
        case 2:
            radix = 8;
            break;
        case 3:
            radix = 10;
            break;
        case 4:
            radix = 16;
            break;
    }

    do{
        printf("N�mero de elementos da lista: ");
        scanf("%u", &n);
        if(n < 1)
            printf("Entrada inv�lida!");
        else break;
    }while(1);

    do{
        printf("N�mero de d�gito dos elementos: ");
        scanf("%u", &digit);
        if(radix == 2 && (digit < 1 || digit > 31)) printf("Valor inv�lido! Intervalo permitido: 1-31 para bin�rio.\n\n");
        else if(radix == 8 && (digit < 1 || digit > 10)) printf("Valor inv�lido! Intervalo permitido: 1-10 para octal.\n\n");
        else if(radix == 10 && (digit < 1 || digit > 9)) printf("Valor inv�lido! Intervalo permitido: 1-9 para decimal.\n\n");
        else if(radix == 16 && (digit < 1 || digit > 7)) printf("Valor inv�lido! Intervalo permitido: 1-7 para hexadecimal.\n\n");
        else break;
    }while(1);

    // Cria��o da lista
    arr = createList(radix, n, digit);

    printf("\nArray desordenado: ");
    printArray(arr, n, radix); // Fun��o para visualizar o array

    radixSort(arr, n, radix); // Fun��o para ordena��o com Radix Sort

    printf("\nArray ordenado: ");
    printArray(arr, n, radix); // Fun��o para visualizar o array

    free(arr);
    printf("\n");
    system("PAUSE");
    return 0;
}
