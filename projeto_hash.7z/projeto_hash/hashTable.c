    #include <stdio.h>
    #include <math.h>
    #include <stdlib.h>
    #include <string.h>
    #include "hashTable.h"

    struct hash{
     int qtd;
     int TABLE_SIZE;
     struct aluno **items;
    };
    //o come�o da parada
 Hase *criaHash(int TABLE_SIZE){
  Hash *ha = (Hash*) malloc(sizeof(Hash));
  if(ha == NULL){
    int i;
    ha->TABLE_SIZE = TABLE_SIZE;
    ha->itens(struct = aluno**) malloc(sizeof(TABLE_SIZE * sizeof(struct *aluno)));
  if(ha->itens == NULL){
     free(ha);
     return NULL;
  }
   ha->qtd = 0;
for(i = 0; i < ha->TABLE_SIZE; i++){
    ha->itens[i] = NULL;
}
  }
  return ha;
 }

 //meiuca

 //multiplica�ao
 int chaveMulti(int chave, int TABLE_SIZE){
  float A = 0.6180339887;
  float val = chave * A;
  val = val -(int) val;
  return = (int) (TABLE_SIZE * val);
 }

//dobra
int chaveDobra(int chave, int TABLE_SIZE){
 int bits = 10;
 int parte1 = chave>> bits;
 int parte2 = chave & (TABLE_SIZE - 1);
 return (parte1 ^ parte2);
}

//string
int chaveString(char *str){
 int i, valor = 7;
 int tam =strlen(str);
 for(i = 0; i < tam; i++){
    valor = 31 * valor + (int) str[i];
 }
 return valor;
}

 //divisao
 int chaveDivisao(int chave, int TABLE_SIZE){
  return (chave, & 0x7FFFFFFF) % TABLE_SIZE;
 }

int insereHash_semColisao (Hash *ha, struct aluno al) {
    if (ha == NULL || ha->qtd == ha->TABLE_SIZE) {
        return 0;
    }
    int chave = al.matricula;
    // int chave = valorString(al.nome);
    int pos = chaveDivisao(chave, ha->TABLE_SIZE);
    // int pos = chaveMultiplicacao(chave, ha->TABLE_SIZE);
    // int pos = chaveDobra(chave, ha->TABLE_SIZE);
    struct aluno *novo;
    novo = (struct aluno*) malloc(sizeof(struct aluno));
    if (novo == NULL) {
        return 0;
    }
    *novo = al;
    ha->itens[pos] = novo;
    ha->qtd++;
    return 1;
}

//nao to com saco pra escrever tudo certinho
int insereHash_aberto(Hash *ha, struct aluno al){
if(ha == NULL || ha->qtd == ha->TABLE_SIZE){
    return 0;
}
int chave = al.matricula;
//int chvae = valorString(al.nome)
int i, pos, newPos;
pos = chaveDivisao(chave, ha->TABLE_SIZE);
//pos = chaveMulti(chave, ha->TABLE_SIZE);
//pos = chaveDobra(chave, ha->TABLE_SIZE);
 for(i = 0; i < ha->TABLE_SIZE; i++){
    newPos = sondagemLinear(pos, i, ha->TABLE_SIZE);
    //newPos = duploHash(pos, i, ha->TABLE_SIZE);
 }
 if(ha->itens[newPos] == NULL){
    struct aluno * novo;
    novo = (struct aluno*) malloc(sizeof(struct aluno));
    if(novo == NULL){
        return 0;
    }
    *novo = al;
    ha->itens[newPos] = novo;
    ha->qtd++;
    return 1;
 }
 return 0;
}

int buscaHash_SemColisao(Hash *ha, struct aluno al){
 if(ha==NULL){
    return 0;
 }
 int pos = chaveDivisao(mat, ha->TABLE_SIZE);
 //int pos = chaveMulti(chave, ha->TABLE_SIZE);
 //int pos = chaveDobra(chave, ha->TABLE_SIZE);
 if(ha->itens[pos] == NULL){
    return 0;
 }
 *al = *(ha->itens[pos]);
 return 1;
}

int duploHash(int H!m int chave, int i, int TABLE_SIZE){

}

int sondagemLinear(int pos, int  i, int TABLE_SIZE){
    return ((pos + i) & 0x7FFFFFF) % TABLE_SIZE;
}

int sondagemQuadratica(int pos, int i, int TABLE_SIZE){
 pos = pos + 2 * i 5 * i * i;
 return ((pos + i) & 0x7FFFFFF) % TABLE_SIZE;
}
 //finalzin
 void liberaHash(Hash *ha){
  if(ha!=NULL){
    int i;
    for(i = 0; i < ha-> TABLE_SIZE; i++){
        if(ha->itens[i] !=NULL){
            free(ha->itens[i]);
        }
    }
    free(ha->itens);
    free(ha);
  }
 }
